let db;

let openRequest = indexedDB.open("ControlVisitas",1);

openRequest.onupgradeneeded = function() {
    let db1 = openRequest.result;
    //crear almacenes, claves, indices
    //solo se puede aqui
    let entradas = db1.createObjectStore('entradas', {keyPath: 'dni'});
    let indEntradaApe = entradas.createIndex('apellidos_ind', 'apellidos');

    let salidas = db1.createObjectStore('salidas', {autoIncrement: true});
    let indSalidaDNI = salidas.createIndex('dni_ind', 'dni');
    let indSalidaApe = salidas.createIndex('apellidosSal_ind', 'apellidos');
};

openRequest.onerror = function() {
  console.error("Error", openRequest.error);
};

openRequest.onsuccess = function() {
  db = openRequest.result;
  console.log("Recogido evento success")
  listarEntradas();
  listarSalidas();
};

function guardaBD(){
  console.log("guardar en el almacen de objetos")
  
  //recuperar los datos
  //generar un objeto para guardar
  entrada = {
    dni: document.getElementById("dni").value,
    nombre: document.getElementById("nombre").value,
    apellidos: document.getElementById("apellidos").value,
    contacto: document.getElementById("contacto").value,
    fechaEntrada: new(Date),
  }


  // guardar el objeto en el almacen de la base de datos

  //(1) crear una transaccion
  let transac = db.transaction("entradas", "readwrite");

  //(2) obtener el almacen
  let entrs = transac.objectStore("entradas"); 

  //(3) aÃ±adir al almacen el objeto
  let resultado = entrs.add(entrada);

  //(4) gestionar los eventos (exito y error) con el resultado de la operacion (insercion)
  resultado.onsuccess = function() { 
    console.log("Entrada agregada al almacen", resultado.result);
  };
  resultado.onerror = function() {
    console.log("Error", resultado.error);
  };

  location.reload();
}

function listarEntradas(){
    //(1) crear una transaccion
    let transac = db.transaction("entradas", "readonly");

    //(2) obtener el almacen
    let entrs = transac.objectStore("entradas");

    //(3) recuperar todos los datos del almacen
    //let salida = lbrs.getAll(IDBKeyRange.bound("0", "1",true, false));
    let salida = entrs.getAll();

    salida.onsuccess = function() {
        let tabla = $("#entradas");

        for(entrada of salida.result){
            let nombre = entrada.nombre;
            let apellidos = entrada.apellidos;
            let dni = entrada.dni;
            let contacto = entrada.contacto;
            let fechaEntrada = entrada.fechaEntrada;
            
            let fila = $("<tr>");

            celdaNombre= $("<td>").text(nombre);

            fila.append(celdaNombre);

            celdaApellidos= $("<td>").text(apellidos);

            fila.append(celdaApellidos);

            celdaDNI= $("<td>").text(dni);

            fila.append(celdaDNI);

            celdaContacto= $("<td>").text(contacto);

            fila.append(celdaContacto);

            celdaFechEntr= $("<td>").text(fechaEntrada);

            fila.append(celdaFechEntr);

            celdaSal = $("<td>")
            console.log(entrada.dni)

            

            let btnRegSalida = $("<button>");
            btnRegSalida.addClass("btnRegSal")
            btnRegSalida.text("→")
            btnRegSalida.on("click", function(){
                guardaSalida(nombre,apellidos,dni,contacto,fechaEntrada);
                borrarEntrada(dni);
            })

            celdaSal.append(btnRegSalida);

            fila.append(celdaSal);

            tabla.append(fila);

        }
    }
    /*
    let res = entrs.getKey("0");

    res.onsuccess = function() {
        console.log(res.result);
    }

    let ti = entrs.index("titulo_ind") //busco el indice en el almacen

    let res1 = ti.getKey("libro 1") //ejecuto la consulta sobre el indice, devuelve las claves

    res1.onsuccess = function() {
        for (keylibro of res1.result){ //recorro el resultado
            console.log(lbrs.get(keylibro));
        }
    }
    */
}

function borrarEntrada(dni){

  // (1) Crear una transacción en modo 'readwrite'
  let transac = db.transaction("entradas", "readwrite");

  // (2) Obtener el almacén (objectStore)
  let entrs = transac.objectStore("entradas");

  // (3) Recuperar la clave (id) mediante la clave primaria (DNI)
  let request = entrs.getKey(dni);

  request.onsuccess = function() {
    let id = request.result;
    let deleteRequest = entrs.delete(id);
  };
  location.reload();
}

function guardaSalida(nombre,apellidos,dni,contacto,fechaEntrada){
    console.log("guardar en el almacen de objetos")
  
  //recuperar los datos
  //generar un objeto para guardar
  salida = {
    dni: dni,
    nombre: nombre,
    apellidos: apellidos,
    contacto: contacto,
    fechaEntrada: fechaEntrada,
    fechaSalida: new(Date),
  }


  // guardar el objeto en el almacen de la base de datos

  //(1) crear una transaccion
  let transac2 = db.transaction("salidas", "readwrite");

  //(2) obtener el almacen
  let sals = transac2.objectStore("salidas"); 

  //(3) aÃ±adir al almacen el objeto
  let resultado = sals.add(salida);

  //(4) gestionar los eventos (exito y error) con el resultado de la operacion (insercion)
  resultado.onsuccess = function() { 
    console.log("Salida agregada al almacen", resultado.result);
  };
  resultado.onerror = function() {
    console.log("Error", resultado.error);
  };
}

function listarSalidas(){
    //(1) crear una transaccion
    let transac = db.transaction("salidas", "readonly");

    //(2) obtener el almacen
    let sals = transac.objectStore("salidas");

    //(3) recuperar todos los datos del almacen
    //let salida = lbrs.getAll(IDBKeyRange.bound("0", "1",true, false));
    let salida = sals.getAll();

    salida.onsuccess = function() {
        let tabla = $("#salidas");

        for(salida of salida.result){
            let fila = $("<tr>");

            celdaNombre= $("<td>").text(salida.nombre);

            fila.append(celdaNombre);

            celdaApellidos= $("<td>").text(salida.apellidos);

            fila.append(celdaApellidos);

            celdaDNI= $("<td>").text(salida.dni);

            fila.append(celdaDNI);

            celdaContacto= $("<td>").text(salida.contacto);

            fila.append(celdaContacto);

            celdaFechEntr= $("<td>").text(salida.fechaEntrada);

            fila.append(celdaFechEntr);

            celdaFechSal= $("<td>").text(salida.fechaSalida);

            fila.append(celdaFechSal);

            tabla.append(fila);

        }
    }
    /*
    let res = entrs.getKey("0");

    res.onsuccess = function() {
        console.log(res.result);
    }

    let ti = entrs.index("titulo_ind") //busco el indice en el almacen

    let res1 = ti.getKey("libro 1") //ejecuto la consulta sobre el indice, devuelve las claves

    res1.onsuccess = function() {
        for (keylibro of res1.result){ //recorro el resultado
            console.log(lbrs.get(keylibro));
        }
    }
    */
}

function buscarEntradaDni(){
  let dniEntrada = $("#dniEnt").val();
  mostrarEntradasPorDNI(dniEntrada);
  console.log(".")
}

function buscarEntradaApellidos(){
  let dniEntrada = $("#apeEnt").val();
  mostrarEntradasPorApellidos(dniEntrada);
}

function buscarSalidaDni(){
  let dniSalida = $("#dniSal").val();
  mostrarSalidasPorDNI(dniSalida);
}

function buscarSalidaApellidos(){
  let apeSalida = $("#apeSal").val();
  mostrarSalidasPorApellidos(apeSalida);
}

function mostrarEntradasPorDNI(dni) {
  // (1) Crear una transacción
  let transac2 = db.transaction("entradas", "readonly");

  // (2) Obtener el almacén
  let entds2 = transac2.objectStore("entradas");

  // (3) Buscar por clave (DNI)
  let getRequest = entds2.get(dni);

  getRequest.onsuccess = function () {
      let result = getRequest.result;

      if (result) {

        let tabla = $("#entradas");
        tabla.empty(); // Limpiar la tabla antes de mostrar los resultados
        let fila = $("<tr>");

        // Recorrer los resultados y agregar filas a la tabla
        celdaNombre = $("<td>").text(result.nombre);
        fila.append(celdaNombre);
        celdaApe = $("<td>").text(result.apellidos);
        fila.append(celdaApe);
        celdaDni = $("<td>").text(result.dni);
        fila.append(celdaDni);
        celdaCont = $("<td>").text(result.contacto);
        fila.append(celdaCont);
        celdaFechaEnt = $("<td>").text(result.fechaEntrada);
        fila.append(celdaFechaEnt);
        celdaFechaSal = $("<td>");

        let btnRegSalida = $("<button>");
        btnRegSalida.addClass("btnRegSal")
        btnRegSalida.text("→")
        btnRegSalida.on("click", function(){
            guardaSalida(result.nombre,result.apellidos,result.dni,result.contacto,result.fechaEntrada);
            borrarEntrada(result.dni);
        })
        celdaFechaSal.append(btnRegSalida);

        fila.append(celdaFechaSal);
        tabla.append(fila);
      } else {
          console.log("Entrada no encontrada");
      }
  };

  getRequest.onerror = function () {
      console.log("Error al buscar la entrada");
  };
}

function mostrarEntradasPorApellidos(apellidos) {
  // (1) Crear una transacción
  let transac2 = db.transaction("entradas", "readonly");

  // (2) Obtener el almacén
  let entds2 = transac2.objectStore("entradas");

  // (3) Utilizar el índice para buscar por apellidos
  let apeIndice = entds2.index("apellidos_ind");
  let getRequest = apeIndice.getAllKeys(apellidos);

  getRequest.onsuccess = function () {
      let result = getRequest.result;

      if (result.length > 0) {
          // Si se encuentran entradas, mostrarlas
          let tabla = $("#entradas");
          tabla.empty(); // Limpiar la tabla antes de mostrar los resultados

          for (let key of result) {
              let getRequestByKey = entds2.get(key);

              getRequestByKey.onsuccess = function () {

                  let entrada = getRequestByKey.result;
                  let fila = $("<tr>");

                  // Recorrer los resultados y agregar filas a la tabla
                  celdaNombre = $("<td>").text(entrada.nombre);
                  fila.append(celdaNombre);
                  celdaApe = $("<td>").text(entrada.apellidos);
                  fila.append(celdaApe);
                  celdaDni = $("<td>").text(entrada.dni);
                  fila.append(celdaDni);
                  celdaCont = $("<td>").text(entrada.contacto);
                  fila.append(celdaCont);
                  celdaFechaEnt = $("<td>").text(entrada.fechaEntrada);
                  fila.append(celdaFechaEnt);
                  celdaFechaSal = $("<td>");

                  let btnRegSalida = $("<button>");
                  btnRegSalida.addClass("btnRegSal")
                  btnRegSalida.text("→")
                  btnRegSalida.on("click", function(){
                      guardaSalida(entrada.nombre,entrada.apellidos,entrada.dni,entrada.contacto,entrada.fechaEntrada);
                      borrarEntrada(entrada.dni);
            })
          celdaFechaSal.append(btnRegSalida);

                  fila.append(celdaFechaSal);
                  tabla.append(fila);
              };
          }
      } else {
          console.log("Entradas no encontradas");
      }
  };

  getRequest.onerror = function () {
      console.log("Error al buscar las entradas");
  };
}

function mostrarSalidasPorDNI(dni) {
  // (1) Crear una transacción
  let transac4 = db.transaction("salidas", "readonly");

  // (2) Obtener el almacén
  let salids2 = transac4.objectStore("salidas");

  // (3) Buscar por clave (DNI)
  let getRequest = salids2.index("dni_ind").get(dni);

  getRequest.onsuccess = function () {
      let result = getRequest.result;

      if (result) {
          // Si se encuentra la salida, mostrarla
          let tabla = $("#salidas");
          tabla.empty(); // Limpiar la tabla antes de mostrar los resultados

          let fila = $("<tr>");
          celdaNombre = $("<td>").text(result.nombre);
          fila.append(celdaNombre);
          celdaApe = $("<td>").text(result.apellidos);
          fila.append(celdaApe);
          celdaDni = $("<td>").text(result.dni);
          fila.append(celdaDni);
          celdaCont = $("<td>").text(result.contacto);
          fila.append(celdaCont);
          celdaFechaEnt = $("<td>").text(result.fechaEntrada);
          fila.append(celdaFechaEnt);
          celdaFechaSal = $("<td>").text(result.fechaSalida);
          fila.append(celdaFechaSal);
          tabla.append(fila);
      } else {
          console.log("Salida no encontrada");
      }
  };

  getRequest.onerror = function () {
      console.log("Error al buscar la salida");
  };
}

function mostrarSalidasPorApellidos(apellidos) {
  // (1) Crear una transacción
  let transac4 = db.transaction("salidas", "readonly");

  // (2) Obtener el almacén
  let salids2 = transac4.objectStore("salidas");

  // (3) Utilizar el índice para buscar por apellidos
  let apeIndice = salids2.index("apellidosSal_ind");
  let getRequest = apeIndice.getAllKeys(apellidos);

  getRequest.onsuccess = function () {
      let result = getRequest.result;

      if (result.length > 0) {
          // Si se encuentran salidas, mostrarlas
          let tabla = $("#salidas");
          tabla.empty(); // Limpiar la tabla antes de mostrar los resultados

          for (let key of result) {
              let getRequestByKey = salids2.get(key);

              getRequestByKey.onsuccess = function () {
                  let salida = getRequestByKey.result;
                  let fila = $("<tr>");

                  // Recorrer los resultados y agregar filas a la tabla
                  celdaNombre = $("<td>").text(salida.nombre);
                  fila.append(celdaNombre);
                  celdaApe = $("<td>").text(salida.apellidos);
                  fila.append(celdaApe);
                  celdaDni = $("<td>").text(salida.dni);
                  fila.append(celdaDni);
                  celdaCont = $("<td>").text(salida.contacto);
                  fila.append(celdaCont);
                  celdaFechaEnt = $("<td>").text(salida.fechaEntrada);
                  fila.append(celdaFechaEnt);
                  celdaFechaSal = $("<td>").text(salida.fechaSalida);
                  fila.append(celdaFechaSal);
                  tabla.append(fila);
              };
          }
      } else {
          console.log("Salidas no encontradas");
      }
  };

  getRequest.onerror = function () {
      console.log("Error al buscar las salidas");
  };
}

function limpiar(){
  $("#dni").val("")
  $("#nombre").val("")
  $("#apellidos").val("")
  $("#contacto").val("")
}