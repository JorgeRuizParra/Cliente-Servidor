#!C:\Users\zx20student122\AppData\Local\Programs\Python\Python311\python.exe

import HtmlVideoJuegos

print("Content-type: text/html\n")

HtmlVideoJuegos.formularioInsertar()